let warningEnabled = true; // Default: Enabled

// Exit warning event
window.addEventListener("beforeunload", function (event) {
    if (warningEnabled) {
        event.preventDefault();
        event.returnValue = ''; // Triggers Chrome's default warning
    }
});

// Listen for changes in the exit warning dropdown
document.getElementById("exitWarning").addEventListener("change", function () {
    warningEnabled = this.value === "yes"; // Enable or disable warning
});

// Change logo when a new option is selected
document.getElementById("logoSelect").addEventListener("change", function () {
    document.getElementById("logo").src = this.value;
});

// Allow user to upload their own logo
document.getElementById("logoUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById("logo").src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Change website title dynamically
document.getElementById("titleInput").addEventListener("input", function () {
    document.title = this.value;
});

// Change favicon dynamically
document.getElementById("faviconSelect").addEventListener("change", function () {
    document.getElementById("favicon").href = this.value;
});

document.getElementById("faviconUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById("favicon").href = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Fullscreen Button Functionality
document.getElementById("fullscreenBtn").addEventListener("click", function () {
    let iframe = document.getElementById("websiteFrame");

    if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
    } else if (iframe.mozRequestFullScreen) { 
        iframe.mozRequestFullScreen();
    } else if (iframe.webkitRequestFullscreen) { 
        iframe.webkitRequestFullscreen();
    } else if (iframe.msRequestFullscreen) { 
        iframe.msRequestFullscreen();
    }
});
