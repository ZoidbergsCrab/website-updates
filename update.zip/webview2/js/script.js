let warningEnabled = true; // Default: Enabled

// Beforeunload event to show exit warning
window.addEventListener("beforeunload", function (event) {
    if (warningEnabled) {
        event.preventDefault();
        event.returnValue = ''; // Triggers Chrome's default warning
    }
});

// Listen for changes in the exit warning dropdown
document.getElementById("exitWarning").addEventListener("change", function () {
    warningEnabled = this.value === "yes";
});

// Change logo when a new option is selected
document.getElementById("logoSelect").addEventListener("change", function () {
    document.getElementById("logo").src = this.value;
});

// Allow user to upload their own logo
document.getElementById("logoUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById("logo").src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Change website title dynamically
document.getElementById("titleInput").addEventListener("input", function () {
    document.title = this.value;
});

// Change favicon dynamically
document.getElementById("faviconUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById("favicon").href = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Change favicon using selection dropdown
document.getElementById("faviconSelect").addEventListener("change", function () {
    document.getElementById("favicon").href = this.value;
});

// Function to fullscreen the embedded website, not just the whole page
function toggleFullscreen() {
    const iframe = document.getElementById("websiteFrame");
    if (!document.fullscreenElement) {
        if (iframe.requestFullscreen) {
            iframe.requestFullscreen();
        } else if (iframe.mozRequestFullScreen) { // Firefox
            iframe.mozRequestFullScreen();
        } else if (iframe.webkitRequestFullscreen) { // Chrome, Safari, Opera
            iframe.webkitRequestFullscreen();
        } else if (iframe.msRequestFullscreen) { // IE/Edge
            iframe.msRequestFullscreen();
        }
    } else {
        document.exitFullscreen();
    }
}

// Function to refresh only the website iframe
function refreshWebsite() {
    const iframe = document.getElementById("websiteFrame");
    iframe.src = iframe.src; // This forces a refresh without reloading the whole page
}
