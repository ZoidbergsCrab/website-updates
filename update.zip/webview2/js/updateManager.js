const currentVersion = "2.0"; // Change this when releasing new versions

// Function to check for updates
function checkForUpdates() {
    console.log("🔍 Checking for updates...");

    const script = document.createElement("script");
    script.src = "https://zoidbergscrab.github.io/website-updates/updates.js"; // Make sure this file exists
    script.onload = function () {
        if (window.updatesData) {
            const latestVersion = window.updatesData.latestVersion;
            const changelog = window.updatesData.changelog;
            const downloadURL = window.updatesData.downloadURL;

            if (latestVersion !== currentVersion) {
                console.log(`✅ Update found: v${latestVersion}`);
                alert(`New update available! 🎉\n\nCurrent: v${currentVersion} → New: v${latestVersion}\n\nChangelog: ${changelog}`);
                downloadUpdate(downloadURL);
            } else {
                console.log("🔄 Already on the latest version.");
                alert("You're already using the latest version!");
            }
        } else {
            console.error("⚠️ No update data found.");
            alert("Could not retrieve update information.");
        }
    };

    script.onerror = function () {
        console.error("❌ Error loading updates.js");
        alert("Failed to check for updates. Try again later.");
    };

    document.body.appendChild(script);
}

// Function to auto-download the update
function downloadUpdate(url) {
    console.log("⬇️ Downloading update:", url);

    fetch(url)
        .then(response => response.blob())
        .then(blob => {
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = "update.zip"; // Forces the file to be saved
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            console.log("✅ Download started successfully!");
        })
        .catch(error => {
            console.error("❌ Error downloading update:", error);
            alert("Failed to download the update. Click here: " + url);
            window.open(url, "_blank"); // Opens in a new tab as a fallback
        });
}
